<?php
class Ganttchart extends AppModel{
	var $name = 'Ganttchart';
}
?>