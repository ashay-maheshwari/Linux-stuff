<?php
class Company extends AppModel{
	public $name = 'Company';
	
	/*var $hasAndBelongsToMany = array(
        'User' =>
            array(
                'className'              => 'User',
                'joinTable'              => 'company_users',
                'foreignKey'             => 'company_id',
                'associationForeignKey'  => 'user_id'
           )
    );*/
}
?>
