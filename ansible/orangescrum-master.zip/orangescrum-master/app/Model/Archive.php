<?php
class Archive extends AppModel{
	var $name = 'Archive';
}
?>
