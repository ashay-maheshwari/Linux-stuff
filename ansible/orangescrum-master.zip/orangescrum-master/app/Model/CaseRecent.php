<?php
class CaseRecent extends AppModel{
	var $name = 'CaseRecent';
}
?>