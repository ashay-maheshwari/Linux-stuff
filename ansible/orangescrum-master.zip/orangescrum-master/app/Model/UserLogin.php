<?php
class UserLogin extends AppModel{
	var $name = 'UserLogin';
}
?>