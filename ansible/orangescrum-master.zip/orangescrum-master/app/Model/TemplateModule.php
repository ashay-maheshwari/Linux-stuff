<?php
class TemplateModule extends AppModel{
	var $name = 'TemplateModule';
}
?>
